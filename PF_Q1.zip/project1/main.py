from flask import Flask , request , render_template
app = Flask(__name__)

@app.route('/')
def printHome():
    return 'Home Page'

@app.route('/upload')
def uploadPath():
     return render_template('requestUserName.html')


@app.route('/hello' , methods = ['GET' , 'POST'])
def printResult():
    #if request.method == 'POST':
        #userName = request.form['user']
        if request.method == 'POST':
            userName = request.form['user']

            return f"Hello {userName}!"
    
if __name__ == "__main__":
    app.run(debug = True)
 